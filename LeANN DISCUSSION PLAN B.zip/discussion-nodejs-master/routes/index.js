

//index page for angularjs
exports.index = function(req, res){
	res.render('index', { title: 'Discussion Node' });
};

