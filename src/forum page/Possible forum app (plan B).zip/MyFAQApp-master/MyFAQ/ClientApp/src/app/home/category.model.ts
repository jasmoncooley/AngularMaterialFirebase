import { Question } from "./question.model";

export class Category {
  title: string;
  questions: Question[];
}
