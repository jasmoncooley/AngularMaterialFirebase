export class Question {
  id: number;
  question_: string;
  answer: string;
  categoryTitle: string;
  customerName: string;
  customerSurname: string;
  customerEmail: string;
  thumbup: number;
  thumbdown: number;
  date: string;
}
